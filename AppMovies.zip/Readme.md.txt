Una Funcionalidad que me gustaria agregar es la carga de mas de 20 opciones, con un contador de paginas,
para ello generaria un metodo el cual iteraria el numero de pagina ya sea de forma acendente o decendente
para poder cambiar de pagina segun el mimite que tenga.