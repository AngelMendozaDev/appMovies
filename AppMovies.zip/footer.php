<script src="Libs/jquery.js"></script>
<script src="Libs/Bootstrapp5/js/bootstrap.min.js"></script>
<script src="Libs/GliderJs/glider.min.js"></script>
<script src="Js/apiSettings.js"></script>
</body>

</html>